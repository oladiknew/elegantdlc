import { useState } from "react";
import { faqItems } from "@/lib/utils/constants";

export default function FAQ() {
  const [expandedFaq, setExpandedFaq] = useState(0);

  const toggleFaq = (index: number) => {
    setExpandedFaq(index === expandedFaq ? -1 : index);
  };

  return (
    <section id="faq" className="py-16 gradient-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-minecraft font-bold mb-3">
            Frequently Asked <span className="text-[#7D9951]">Questions</span>
          </h2>
          <p className="max-w-2xl mx-auto opacity-80">
            Find answers to common questions about Elegant DLC.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqItems.map((faq, index) => (
              <div key={index} className="pixel-border bg-[#3B3B3B] overflow-hidden">
                <button 
                  className="w-full flex justify-between items-center p-4 text-left font-minecraft"
                  onClick={() => toggleFaq(index)}
                >
                  <span>{faq.question}</span>
                  <i className={`fas fa-chevron-down transition-transform ${expandedFaq === index ? 'rotate-180' : ''}`}></i>
                </button>
                <div className={`p-4 pt-0 border-t border-gray-700 ${expandedFaq === index ? 'block' : 'hidden'}`}>
                  <p className="opacity-80">{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <p className="mb-4">Still have questions?</p>
            <a href="#" className="minecraft-btn py-2 px-6 font-minecraft">
              CONTACT SUPPORT
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
