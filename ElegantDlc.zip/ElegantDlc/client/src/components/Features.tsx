import { features } from "@/lib/utils/constants";

export default function Features() {
  return (
    <section id="features" className="py-16 gradient-bg">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-minecraft font-bold mb-3">
            Premium <span className="text-[#7D9951]">Features</span>
          </h2>
          <p className="max-w-2xl mx-auto opacity-80">
            Elegant DLC comes packed with powerful features designed to enhance your Minecraft experience while staying undetected.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => (
            <div key={index} className="pixel-border bg-[#3B3B3B] p-6 hover:bg-opacity-90 transition-all">
              <div className={`w-12 h-12 ${feature.color} rounded-md flex items-center justify-center mb-4`}>
                <i className={`fas fa-${feature.icon} text-xl`}></i>
              </div>
              <h3 className="text-xl font-minecraft font-bold mb-2">{feature.title}</h3>
              <p className="opacity-80">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a href="#download" className="minecraft-btn py-3 px-8 text-lg font-minecraft font-bold">
            GET ALL FEATURES
          </a>
        </div>
      </div>
    </section>
  );
}
