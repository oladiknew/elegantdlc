export default function CallToAction() {
  return (
    <section className="py-16 bg-[#242424] relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute w-32 h-32 bg-[#7D9951] rounded-full -top-10 -left-10"></div>
        <div className="absolute w-40 h-40 bg-[#4A76FD] rounded-full -bottom-20 -right-20"></div>
        <div className="absolute w-24 h-24 bg-[#E43B44] rounded-full bottom-40 left-1/4"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-minecraft font-bold mb-6">
            Ready to <span className="text-[#7D9951]">Dominate</span> Minecraft?
          </h2>
          <p className="text-lg md:text-xl opacity-80 mb-8 max-w-2xl mx-auto">
            Join thousands of players who have already enhanced their Minecraft experience with Elegant DLC.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="#download" className="minecraft-btn py-3 px-8 text-lg font-minecraft font-bold bg-[#7D9951] border-green-800">
              GET STARTED NOW
            </a>
            <a href="#features" className="minecraft-btn py-3 px-8 text-lg font-minecraft font-bold">
              EXPLORE FEATURES
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
