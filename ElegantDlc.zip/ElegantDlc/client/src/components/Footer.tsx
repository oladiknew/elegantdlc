export default function Footer() {
  return (
    <footer className="bg-[#3B3B3B] pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-[#7D9951] rounded mr-2"></div>
              <h2 className="text-xl font-minecraft font-bold">
                <span className="text-[#7D9951]">Elegant</span>{" "}
                <span className="text-[#4A76FD]">DLC</span>
              </h2>
            </div>
            <p className="opacity-70 text-sm">
              Premium Minecraft enhancement tool designed to elevate your gameplay experience.
            </p>
            <div className="flex mt-4 space-x-4">
              <a href="#" className="text-white hover:text-[#7D9951] transition-colors">
                <i className="fab fa-discord text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#7D9951] transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#7D9951] transition-colors">
                <i className="fab fa-youtube text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#7D9951] transition-colors">
                <i className="fab fa-telegram text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-minecraft font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 opacity-70">
              <li>
                <a href="#features" className="hover:text-[#7D9951] transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#7D9951] transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#download" className="hover:text-[#7D9951] transition-colors">
                  Download
                </a>
              </li>
              <li>
                <a href="#install" className="hover:text-[#7D9951] transition-colors">
                  Installation
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#7D9951] transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-minecraft font-bold mb-4">Support</h3>
            <ul className="space-y-2 opacity-70">
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Discord Server
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Knowledge Base
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  System Requirements
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Report a Bug
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-minecraft font-bold mb-4">Legal</h3>
            <ul className="space-y-2 opacity-70">
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  Refund Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-[#7D9951] transition-colors">
                  EULA
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-6 text-center">
          <p className="text-sm opacity-50">
            &copy; {new Date().getFullYear()} Elegant DLC. All rights reserved. Not affiliated with Mojang Studios or Microsoft.
          </p>
          <p className="text-xs opacity-50 mt-2">
            Minecraft is a trademark of Mojang Studios. Elegant DLC is a third-party tool not approved by or associated with Mojang Studios.
          </p>
        </div>
      </div>
    </footer>
  );
}
