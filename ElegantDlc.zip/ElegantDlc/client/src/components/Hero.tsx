import { useState, useEffect } from "react";

export default function Hero() {
  return (
    <section className="relative min-h-[80vh] flex items-center py-12">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1607988795691-3d0147b43231?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')" }}
      >
        <div className="absolute inset-0 bg-[#242424] bg-opacity-75"></div>
      </div>

      <div className="container mx-auto px-4 z-10 relative">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <h2 className="text-4xl md:text-6xl font-minecraft font-bold">
              <span className="text-[#7D9951]">Unleash</span>{" "}
              <span className="text-white">Your</span>
              <span className="text-[#4A76FD] block">Minecraft Potential</span>
            </h2>
            <p className="text-lg md:text-xl opacity-90">
              Elevate your gaming experience with Elegant DLC, the premium Minecraft cheat designed for players who demand the best. Gain the competitive edge while maintaining a smooth, undetectable gameplay experience.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#download" className="minecraft-btn py-3 px-8 text-lg font-minecraft font-bold">
                GET ELEGANT DLC
              </a>
              <a href="#features" className="minecraft-btn py-3 px-8 bg-[#3B3B3B] text-lg font-minecraft font-bold">
                EXPLORE FEATURES
              </a>
            </div>
            <div className="flex items-center space-x-3 mt-6">
              <div className="flex -space-x-2">
                <div className="w-10 h-10 rounded-full border-2 border-[#242424] bg-gray-500"></div>
                <div className="w-10 h-10 rounded-full border-2 border-[#242424] bg-gray-600"></div>
                <div className="w-10 h-10 rounded-full border-2 border-[#242424] bg-gray-700"></div>
              </div>
              <p className="text-sm opacity-80">
                Trusted by <span className="font-bold text-[#7D9951]">10,000+</span> players worldwide
              </p>
            </div>
          </div>
          <div className="pixel-border p-1 bg-[#3B3B3B] animate-float hidden md:block">
            <div className="w-full h-auto aspect-video bg-gray-800"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
