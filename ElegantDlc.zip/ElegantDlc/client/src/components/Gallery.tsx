import { galleryImages } from "@/lib/utils/constants";

export default function Gallery() {
  return (
    <section id="gallery" className="py-16 bg-[#242424]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-minecraft font-bold mb-3">
            See <span className="text-[#4A76FD]">Elegant DLC</span> in Action
          </h2>
          <p className="max-w-2xl mx-auto opacity-80">
            Browse our gallery showing powerful features and incredible gameplay possibilities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {galleryImages.map((image, index) => (
            <div key={index} className="pixel-border overflow-hidden group">
              <div className="w-full h-64 bg-gray-800 transition-transform duration-300 group-hover:scale-110"></div>
              <div className="p-3 bg-[#3B3B3B]">
                <h3 className="font-minecraft">{image.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
