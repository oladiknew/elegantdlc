import { installSteps, installationGuide } from "@/lib/utils/constants";

export default function Installation() {
  return (
    <section id="install" className="py-16 bg-[#242424]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-minecraft font-bold mb-3">
            Easy <span className="text-[#4A76FD]">Installation</span>
          </h2>
          <p className="max-w-2xl mx-auto opacity-80">
            Follow these simple steps to get Elegant DLC up and running.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            {installSteps.map((step, index) => (
              <div key={index} className="pixel-border bg-[#3B3B3B] p-6">
                <div className={`w-12 h-12 ${
                  index === 0 ? "bg-[#7D9951]" : 
                  index === 1 ? "bg-[#4A76FD]" : 
                  "bg-[#E43B44]"
                } rounded-full flex items-center justify-center mb-4 mx-auto`}>
                  <span className="font-minecraft font-bold text-xl">{step.number}</span>
                </div>
                <h3 className="text-xl font-minecraft font-bold mb-2 text-center">{step.title}</h3>
                <p className="text-center opacity-80">{step.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 pixel-border bg-[#3B3B3B] p-6">
            <h3 className="text-xl font-minecraft font-bold mb-4">Detailed Installation Guide</h3>
            <ol className="space-y-4 ml-6 list-decimal">
              {installationGuide.map((item, index) => (
                <li key={index}>
                  <span className="font-bold">{item.title}</span>
                  <p className="opacity-80">{item.description}</p>
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-8 text-center">
            <a href="#download" className="minecraft-btn py-3 px-8 text-lg font-minecraft font-bold">
              DOWNLOAD NOW
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
