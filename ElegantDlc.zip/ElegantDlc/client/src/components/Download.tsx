import { packages } from "@/lib/utils/constants";

export default function Download() {
  return (
    <section id="download" className="py-16 gradient-bg">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto pixel-border bg-[#3B3B3B] p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-minecraft font-bold mb-3">
              Download <span className="text-[#7D9951]">Elegant DLC</span>
            </h2>
            <p className="opacity-80">Choose the package that best fits your gameplay needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {packages.map((pkg, index) => (
              <div 
                key={index} 
                className={`pixel-border ${pkg.isPopular ? 'bg-[#3B3B3B]' : 'bg-[#242424]'} p-6 flex flex-col h-full relative`}
              >
                {pkg.isPopular && (
                  <div className="absolute -top-4 left-0 right-0 flex justify-center">
                    <span className="bg-[#7D9951] text-white text-sm py-1 px-3 font-minecraft">
                      MOST POPULAR
                    </span>
                  </div>
                )}
                <div className="mb-4">
                  <h3 className="text-xl font-minecraft font-bold">{pkg.name}</h3>
                  <div className="flex items-end">
                    <span className="text-2xl font-bold">{pkg.price}</span>
                    <span className="text-sm opacity-70 ml-1">{pkg.period}</span>
                  </div>
                </div>
                <ul className="mb-6 space-y-2 flex-grow">
                  {pkg.features.map((feature, featureIndex) => (
                    <li 
                      key={featureIndex} 
                      className={`flex items-start ${!feature.included ? 'opacity-50' : ''}`}
                    >
                      <i 
                        className={`fas fa-${feature.included ? 'check text-[#7D9951]' : 'times text-[#E43B44]'} mt-1 mr-2`}
                      ></i>
                      <span>{feature.name}</span>
                    </li>
                  ))}
                </ul>
                <a 
                  href="#" 
                  className={`minecraft-btn py-2 w-full text-center font-minecraft ${
                    pkg.isPopular ? 'bg-[#7D9951] border-green-800' : ''
                  }`}
                >
                  DOWNLOAD
                </a>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center text-sm opacity-70">
            <p>By downloading, you agree to our Terms of Service and Privacy Policy</p>
          </div>
        </div>
      </div>
    </section>
  );
}
