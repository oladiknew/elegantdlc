import { useState } from "react";
import { Link } from "wouter";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="relative z-10">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <div className="flex items-center mr-10">
            <div className="w-8 h-8 bg-[#7D9951] rounded mr-2"></div>
            <h1 className="text-2xl font-minecraft font-bold">
              <span className="text-[#7D9951]">Elegant</span>{" "}
              <span className="text-[#4A76FD]">DLC</span>
            </h1>
          </div>
          <ul className="hidden md:flex space-x-8">
            <li>
              <a href="#features" className="hover:text-[#7D9951] transition-colors">
                Features
              </a>
            </li>
            <li>
              <a href="#gallery" className="hover:text-[#7D9951] transition-colors">
                Gallery
              </a>
            </li>
            <li>
              <a href="#download" className="hover:text-[#7D9951] transition-colors">
                Download
              </a>
            </li>
            <li>
              <a href="#install" className="hover:text-[#7D9951] transition-colors">
                Installation
              </a>
            </li>
            <li>
              <a href="#faq" className="hover:text-[#7D9951] transition-colors">
                FAQ
              </a>
            </li>
          </ul>
        </div>
        <div>
          <a href="#download" className="minecraft-btn py-2 px-6 font-minecraft text-lg font-bold">
            DOWNLOAD NOW
          </a>
          <button className="ml-4 block md:hidden" onClick={toggleMenu}>
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div className={`px-4 py-2 bg-[#3B3B3B] md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
        <ul className="space-y-3">
          <li>
            <a 
              href="#features" 
              className="block py-2 hover:text-[#7D9951] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Features
            </a>
          </li>
          <li>
            <a 
              href="#gallery" 
              className="block py-2 hover:text-[#7D9951] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Gallery
            </a>
          </li>
          <li>
            <a 
              href="#download" 
              className="block py-2 hover:text-[#7D9951] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Download
            </a>
          </li>
          <li>
            <a 
              href="#install" 
              className="block py-2 hover:text-[#7D9951] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Installation
            </a>
          </li>
          <li>
            <a 
              href="#faq" 
              className="block py-2 hover:text-[#7D9951] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              FAQ
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
