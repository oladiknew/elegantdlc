import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Gallery from "@/components/Gallery";
import Download from "@/components/Download";
import Installation from "@/components/Installation";
import FAQ from "@/components/FAQ";
import CallToAction from "@/components/CallToAction";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#242424] text-white font-sans">
      <Header />
      <Hero />
      <Features />
      <Gallery />
      <Download />
      <Installation />
      <FAQ />
      <CallToAction />
      <Footer />
    </div>
  );
}
