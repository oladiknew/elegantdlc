export const features = [
  {
    icon: "eye",
    color: "bg-[#7D9951]",
    title: "ESP & Wallhack",
    description: "See players, mobs, ores, and structures through walls with customizable colors and distance settings."
  },
  {
    icon: "bolt",
    color: "bg-[#4A76FD]",
    title: "Auto-Mining",
    description: "Automatically mine for valuable resources with intelligent pathfinding and ore detection algorithms."
  },
  {
    icon: "crosshairs",
    color: "bg-[#E43B44]",
    title: "Combat Enhancements",
    description: "Gain the upper hand with aimbot, criticals, reach adjustment, and auto-healing functionalities."
  },
  {
    icon: "running",
    color: "bg-[#5C4033]",
    title: "Movement Hacks",
    description: "Fly, speed, no-fall damage, and water walking capabilities to traverse the world with ease."
  },
  {
    icon: "shield-alt",
    color: "bg-[#7D9951]",
    title: "Anti-Detection",
    description: "Advanced bypass systems for popular anti-cheat plugins to keep your account safe from bans."
  },
  {
    icon: "sliders-h",
    color: "bg-[#4A76FD]",
    title: "Customizable GUI",
    description: "Elegant interface with extensive customization options to tailor the cheat to your preferences."
  }
];

export const galleryImages = [
  {
    title: "ESP Visualization",
    imageUrl: "https://images.unsplash.com/photo-1627856014729-57f85c7e18f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "Auto-Mining System",
    imageUrl: "https://images.unsplash.com/photo-1505764761634-1d77b57e1966?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "Combat Enhancement",
    imageUrl: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "Customizable Interface",
    imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "Flight Mode",
    imageUrl: "https://images.unsplash.com/photo-1594904351111-a072f80b1a71?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "X-Ray Vision",
    imageUrl: "https://images.unsplash.com/photo-1607706189992-eae578626c86?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
  }
];

export const packages = [
  {
    name: "Basic",
    price: "$9.99",
    period: "/month",
    isPopular: false,
    features: [
      { name: "ESP & Wallhack", included: true },
      { name: "Basic Combat Enhancements", included: true },
      { name: "Movement Hacks", included: true },
      { name: "Auto-Mining", included: false },
      { name: "Advanced Anti-Detection", included: false }
    ]
  },
  {
    name: "Premium",
    price: "$19.99",
    period: "/month",
    isPopular: true,
    features: [
      { name: "ESP & Wallhack", included: true },
      { name: "Full Combat Suite", included: true },
      { name: "Advanced Movement Hacks", included: true },
      { name: "Auto-Mining", included: true },
      { name: "Basic Anti-Detection", included: true }
    ]
  },
  {
    name: "Elite",
    price: "$29.99",
    period: "/month",
    isPopular: false,
    features: [
      { name: "All Premium Features", included: true },
      { name: "Advanced Anti-Detection", included: true },
      { name: "Priority Updates", included: true },
      { name: "Custom Configs", included: true },
      { name: "24/7 Support", included: true }
    ]
  }
];

export const installSteps = [
  {
    number: "1",
    title: "Download",
    description: "Download the Elegant DLC launcher from our website after purchasing."
  },
  {
    number: "2",
    title: "Install",
    description: "Run the installer and follow the on-screen instructions to set up the cheat."
  },
  {
    number: "3",
    title: "Play",
    description: "Launch Minecraft through our launcher and enjoy your enhanced gameplay!"
  }
];

export const installationGuide = [
  {
    title: "Download the Launcher",
    description: "After purchase, download the Elegant DLC launcher from your account dashboard."
  },
  {
    title: "Disable Antivirus",
    description: "Temporarily disable your antivirus software as it may flag the cheat as malicious."
  },
  {
    title: "Run the Installer",
    description: "Execute the downloaded file and follow the installation wizard."
  },
  {
    title: "Login to the Launcher",
    description: "Enter your Elegant DLC account credentials in the launcher."
  },
  {
    title: "Select Minecraft Version",
    description: "Choose your desired Minecraft version from the dropdown menu."
  },
  {
    title: "Configure Settings",
    description: "Customize your cheat settings or load a preset configuration."
  },
  {
    title: "Launch and Play",
    description: "Hit the play button and enjoy your enhanced Minecraft experience!"
  }
];

export const faqItems = [
  {
    question: "Is Elegant DLC safe to use?",
    answer: "Yes, Elegant DLC is designed with safety in mind. Our anti-detection technology helps you stay undetected while using the cheat. However, as with any third-party software, there's always a small risk. We recommend using alt accounts for the safest experience."
  },
  {
    question: "Which Minecraft versions are supported?",
    answer: "Elegant DLC currently supports Minecraft versions 1.8 through 1.19. We regularly update our cheat to support the latest Minecraft versions shortly after their release."
  },
  {
    question: "Can I use Elegant DLC on multiplayer servers?",
    answer: "Yes, Elegant DLC works on most multiplayer servers. However, servers with advanced anti-cheat systems may detect some features. Our Premium and Elite packages include enhanced bypass capabilities for popular server anti-cheat plugins."
  },
  {
    question: "How do I get updates for Elegant DLC?",
    answer: "Our launcher automatically checks for updates when you start it. Elite users receive priority updates as soon as they're available, while Basic and Premium users typically receive updates within 24-48 hours."
  },
  {
    question: "Can I get a refund if I'm not satisfied?",
    answer: "We offer a 24-hour money-back guarantee if you're unsatisfied with our product. Please contact our support team within 24 hours of purchase to process your refund."
  },
  {
    question: "Do you offer customer support?",
    answer: "Yes, all packages include customer support through our Discord server and ticket system. Elite users receive priority 24/7 support with faster response times."
  }
];
